var mataApp = angular.module('mataApp', ["ngRoute"]);

//mataApp.config(['$locationProvider', '$routeProvider', function ($locationProvider, $routeProvider) {
//    $routeProvider
//        .when("/", {
//            templateUrl: "partials/home.html"
//        })
//        .when("/kit", {
//            templateUrl: "/partials/kit.html"
//        })
//        .when("/works", {
//            templateUrl: "/partials/works.html"
//        });
//
//    //    $locationProvider.html5mode({
//    //        enabled: true,
//    //        requireBase: false
//    //    });
//    //    $locationProvider.html5Mode(true);
//    $locationProvider.html5Mode(true);
//    //    $locationProvider.hashPrefix(); // Removes index.html in URL
//}]);

mataApp.config(function ($routeProvider, $locationProvider) {
    $routeProvider
        .when("/", {
            templateUrl: "partials/home.html"
        })
        .when("/works", {
            templateUrl: "partials/works.html"
        })
        .when("/kit", {
            templateUrl: "partials/kit.html"
        })
        .when("/pricing", {
            templateUrl: "partials/pricing.html"
        })
        .when("/contact", {
            templateUrl: "partials/contact.html"
        })
        .otherwise({
            redirectTo: "/"
        });
    $locationProvider.html5Mode({
        enabled: true,
        requireBase: false
    });
});

mataApp.controller("homeController", function ($http, $route) {

    var vm = this;
    vm.reloadData = function () {
        $route.reload();
    }

});

mataApp.controller("worksController", function ($scope, $http, $route) {
    var vm = this;
    vm.reloadData = function () {
        $route.reload();
    }

    $http.get("api/works.json")
        .then(function (response) {
            $scope.works = response.data;
        });

});

mataApp.controller("pricingController", function ($http, $route) {
    var vm = this;
    vm.reloadData = function () {
        $route.reload();
    }
});

mataApp.controller("kitController", function ($http, $route) {
    var vm = this;
    vm.reloadData = function () {
        $route.reload();
    }
});

mataApp.controller("contactController", function ($http, $route) {
    var vm = this;
    vm.reloadData = function () {
        $route.reload();
    }
});
